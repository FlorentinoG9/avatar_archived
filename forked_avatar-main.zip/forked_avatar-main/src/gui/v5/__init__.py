"""
Avatar GUI Version 5
Current production version of the Avatar BCI GUI
"""
