"""
Avatar GUI module
Contains all GUI-related code including layouts, backends, and assets
"""
