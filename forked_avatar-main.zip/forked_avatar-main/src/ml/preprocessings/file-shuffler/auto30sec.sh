#!/usr/bin/bash
#Authors: Brady Theisen
while true; do
	bash run.sh
	sleep 30
done
