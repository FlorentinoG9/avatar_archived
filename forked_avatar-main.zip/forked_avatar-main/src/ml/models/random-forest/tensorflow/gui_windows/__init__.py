"""GUI Windows module for TensorFlow Random Forest model."""
