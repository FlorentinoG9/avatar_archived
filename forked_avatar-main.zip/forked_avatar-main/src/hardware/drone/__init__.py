"""
Drone hardware controller module
"""
