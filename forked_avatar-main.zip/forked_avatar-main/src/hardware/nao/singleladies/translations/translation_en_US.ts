<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>alright</source>
            <comment>Text</comment>
            <translation type="unfinished">alright</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello, I did not understand you</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello, I did not understand you</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>not what i need to hear</source>
            <comment>Text</comment>
            <translation type="unfinished">not what i need to hear</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>alright</source>
            <comment>Text</comment>
            <translation type="obsolete">alright</translation>
        </message>
        <message>
            <source>I am ready to hear the command.</source>
            <comment>Text</comment>
            <translation type="obsolete">I am ready to hear the command.</translation>
        </message>
    </context>
</TS>
