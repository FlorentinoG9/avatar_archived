<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>Hear/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>Sing/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="Sing/behavior.xar" line="0"/>
            <source>Alright</source>
            <comment>Text</comment>
            <translation type="unfinished">Alright</translation>
        </message>
    </context>
    <context>
        <name>Sing/behavior.xar:/Say (1)</name>
        <message>
            <source>I did not understand you</source>
            <comment>Text</comment>
            <translation type="obsolete">I did not understand you</translation>
        </message>
    </context>
    <context>
        <name>Sing/behavior.xar:/Say Error</name>
        <message>
            <location filename="Sing/behavior.xar" line="0"/>
            <source>I did not understand you</source>
            <comment>Text</comment>
            <translation type="unfinished">I did not understand you</translation>
        </message>
    </context>
    <context>
        <name>Talk/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>All right</source>
            <comment>Text</comment>
            <translation type="obsolete">All right</translation>
        </message>
    </context>
</TS>
