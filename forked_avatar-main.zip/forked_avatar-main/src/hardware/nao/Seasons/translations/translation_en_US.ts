<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Choice</name>
        <message>
            <source>no/no nao/disagree/I disagree</source>
            <comment>SpeechReco negative</comment>
            <translation type="vanished">no/no nao/disagree/I disagree</translation>
        </message>
        <message>
            <source>yes/yes nao/agree/I agree/of course</source>
            <comment>SpeechReco positive</comment>
            <translation type="vanished">yes/yes nao/agree/I agree/of course</translation>
        </message>
        <message>
            <source>help/help me/i don't know</source>
            <comment>SpeechReco help</comment>
            <translation type="vanished">help/help me/i don't know</translation>
        </message>
        <message>
            <source>exit/stop/quit</source>
            <comment>SpeechReco exit</comment>
            <translation type="vanished">exit/stop/quit</translation>
        </message>
        <message>
            <source>repeat/pardon/what/excuse me</source>
            <comment>SpeechReco repeat</comment>
            <translation type="vanished">repeat/pardon/what/excuse me</translation>
        </message>
        <message>
            <source>I understood %s. Is that correct?</source>
            <comment>TTS confirmation</comment>
            <translation type="vanished">I understood %s. Is that correct?</translation>
        </message>
        <message>
            <source>, / or </source>
            <comment>TTS enumMarks</comment>
            <translation type="vanished">, / or </translation>
        </message>
        <message>
            <source>No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</source>
            <comment>TTS helpEnumChoices</comment>
            <translation type="vanished">No answer is really expected. /Your answer can be %s. /Your answer can be for example %s. /%s?</translation>
        </message>
        <message>
            <source> you can ask me: %s. </source>
            <comment>TTS helpEnumDefault</comment>
            <translation type="vanished"> you can ask me: %s. </translation>
        </message>
        <message>
            <source>You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</source>
            <comment>TTS helpTactile</comment>
            <translation type="vanished">You can also use my tactile sensor to choose the answer./\Pau=600\ Press the front or the rear of my skull cap to go through all of the available answers. Press then the circle in the middle to validate your choice.</translation>
        </message>
        <message>
            <source>I did not understand. </source>
            <comment>TTS notUnderstood</comment>
            <translation type="vanished">I did not understand. </translation>
        </message>
        <message>
            <source>No question has been defined, so I cannot repeat it. </source>
            <comment>TTS noQuestion</comment>
            <translation type="vanished">No question has been defined, so I cannot repeat it. </translation>
        </message>
        <message>
            <source>There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </source>
            <comment>TTS notUnderstoodAnims</comment>
            <translation type="vanished">There is too much noise here! /Try to talk to me more distinctly. /I can't hear you very well. </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hello, yes I am nao</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello, yes I am nao</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Spring is a wonderful season! Do you enjoy seeing the flowers bloom or going on hikes during that time?</source>
            <comment>Text</comment>
            <translation type="unfinished">Spring is a wonderful season! Do you enjoy seeing the flowers bloom or going on hikes during that time?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hello, yes I am r 2 d 2</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello, yes I am r 2 d 2</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Summer is specially good for going to the beach or to do a backyard BBQ. Have you ever attended an outdoor music festival during the summer?</source>
            <comment>Text</comment>
            <translation type="unfinished">Summer is specially good for going to the beach or to do a backyard BBQ. Have you ever attended an outdoor music festival during the summer?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello, I did not understand you</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello, I did not understand you</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hello, yes I am c 3 p o</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello, yes I am c 3 p o</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Autumn is a cozy season! Do you enjoy drinking hot apple cider or going on hayrides during that time?</source>
            <comment>Text</comment>
            <translation type="unfinished">Autumn is a cozy season! Do you enjoy drinking hot apple cider or going on hayrides during that time?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Winter is a great season for indoor activities! Do you enjoy building snowmen making snow angels, or going ice skating during that time?</source>
            <comment>Text</comment>
            <translation type="unfinished">Winter is a great season for indoor activities! Do you enjoy building snowmen making snow angels, or going ice skating during that time?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (5)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>What is your favorite season?</source>
            <comment>Text</comment>
            <translation type="unfinished">What is your favorite season?</translation>
        </message>
    </context>
</TS>
