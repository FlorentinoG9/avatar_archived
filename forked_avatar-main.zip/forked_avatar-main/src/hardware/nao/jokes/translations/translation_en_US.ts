<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Bicycle Joke</name>
        <message>
            <source>Why couldn't the bicycle stand up by itself?
</source>
            <comment>Text</comment>
            <translation type="obsolete">Why couldn't the bicycle stand up by itself?
</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Coffee Joke</name>
        <message>
            <source>Why did the coffee file a police report?</source>
            <comment>Text</comment>
            <translation type="obsolete">Why did the coffee file a police report?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Correct</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Correct (1)</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Correct (2)</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Correct (3)</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Correct (4)</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Egg Joke</name>
        <message>
            <source>Why don't eggs tell jokes?</source>
            <comment>Text</comment>
            <translation type="obsolete">Why don't eggs tell jokes?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Pasta Joke</name>
        <message>
            <source>What do you call a fake noodle?</source>
            <comment>Text</comment>
            <translation type="obsolete">What do you call a fake noodle?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>What was that?</source>
            <comment>Text</comment>
            <translation type="obsolete">What was that?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Scarecrow Joke</name>
        <message>
            <source>Why did the scarecrow win an award?</source>
            <comment>Text</comment>
            <translation type="obsolete">Why did the scarecrow win an award?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Test</name>
        <message>
            <source>Test</source>
            <comment>Text</comment>
            <translation type="obsolete">Test</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Wrong</name>
        <message>
            <source>Because it was two-tired!</source>
            <comment>Text</comment>
            <translation type="obsolete">Because it was two-tired!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Wrong (1)</name>
        <message>
            <source>An impasta!</source>
            <comment>Text</comment>
            <translation type="obsolete">An impasta!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Wrong (2)</name>
        <message>
            <source>Because it got mugged!</source>
            <comment>Text</comment>
            <translation type="obsolete">Because it got mugged!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Wrong (3)</name>
        <message>
            <source>Because they'd crack each other up!</source>
            <comment>Text</comment>
            <translation type="obsolete">Because they'd crack each other up!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Wrong (4)</name>
        <message>
            <source>Because he was outstanding in his field!</source>
            <comment>Text</comment>
            <translation type="obsolete">Because he was outstanding in his field!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Bicycle Correct</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="unfinished">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Bicycle Joke</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Why couldn't the bicycle stand up by itself?
</source>
            <comment>Text</comment>
            <translation type="unfinished">Why couldn't the bicycle stand up by itself?
</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Bicycle Wrong</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Because it was two-tired!</source>
            <comment>Text</comment>
            <translation type="unfinished">Because it was two-tired!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Coffee Correct</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="unfinished">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Coffee Joke</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Why did the coffee file a police report?</source>
            <comment>Text</comment>
            <translation type="unfinished">Why did the coffee file a police report?</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Coffee Wrong</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Because it got mugged!</source>
            <comment>Text</comment>
            <translation type="unfinished">Because it got mugged!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Correct</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Correct (1)</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Correct (2)</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Correct (3)</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Correct (4)</name>
        <message>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="obsolete">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Egg Correct</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="unfinished">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Egg Joke</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Why don't eggs tell jokes?</source>
            <comment>Text</comment>
            <translation type="unfinished">Why don't eggs tell jokes?</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Egg Wrong</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Because they'd crack each other up!</source>
            <comment>Text</comment>
            <translation type="unfinished">Because they'd crack each other up!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Pasta Correct</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="unfinished">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Pasta Joke</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>What do you call a fake noodle?</source>
            <comment>Text</comment>
            <translation type="unfinished">What do you call a fake noodle?</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Pasta Wrong</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>An impasta!</source>
            <comment>Text</comment>
            <translation type="unfinished">An impasta!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Say Hello</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Scarecrow Correct</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Exactly right. HAHAHA</source>
            <comment>Text</comment>
            <translation type="unfinished">Exactly right. HAHAHA</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Scarecrow Joke</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Why did the scarecrow win an award?</source>
            <comment>Text</comment>
            <translation type="unfinished">Why did the scarecrow win an award?</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Scarecrow Wrong</name>
        <message>
            <location filename="jokes/behavior.xar" line="0"/>
            <source>Because he was outstanding in his field!</source>
            <comment>Text</comment>
            <translation type="unfinished">Because he was outstanding in his field!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Wrong</name>
        <message>
            <source>Because it was two-tired!</source>
            <comment>Text</comment>
            <translation type="obsolete">Because it was two-tired!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Wrong (1)</name>
        <message>
            <source>An impasta!</source>
            <comment>Text</comment>
            <translation type="obsolete">An impasta!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Wrong (2)</name>
        <message>
            <source>Because it got mugged!</source>
            <comment>Text</comment>
            <translation type="obsolete">Because it got mugged!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Wrong (3)</name>
        <message>
            <source>Because they'd crack each other up!</source>
            <comment>Text</comment>
            <translation type="obsolete">Because they'd crack each other up!</translation>
        </message>
    </context>
    <context>
        <name>jokes/behavior.xar:/Wrong (4)</name>
        <message>
            <source>Because he was outstanding in his field!</source>
            <comment>Text</comment>
            <translation type="obsolete">Because he was outstanding in his field!</translation>
        </message>
    </context>
</TS>
