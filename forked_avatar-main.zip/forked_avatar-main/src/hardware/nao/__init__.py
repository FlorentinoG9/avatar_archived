"""
NAO robot hardware controller module
"""
