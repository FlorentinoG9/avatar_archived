"""
Hardware controllers module for Avatar BCI application
Includes NAO robot, drone, and BCI interfaces
"""
