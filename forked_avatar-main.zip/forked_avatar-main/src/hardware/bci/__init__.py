"""
Brain-Computer Interface (BCI) hardware controller module
"""
