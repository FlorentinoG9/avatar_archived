"""Tests package for avatar-forked project."""
